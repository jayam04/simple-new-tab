# simple-new-tab
simple and beautiful new tab for chrome.
