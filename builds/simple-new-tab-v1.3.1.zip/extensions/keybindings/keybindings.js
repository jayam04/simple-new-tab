document.addEventListener('DOMContentLoaded', () => {
    console.log('Key Bindings extension loaded');
    // Add key binding logic here
});
