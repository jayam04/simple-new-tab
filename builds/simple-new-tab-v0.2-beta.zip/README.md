# simple new chrome tab.
simple and beautiful new tab for chrome.
