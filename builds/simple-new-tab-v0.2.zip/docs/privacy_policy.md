# Privacy Policy.

Our extension doesn't collect any userdata.  
